<div class="deroule">
      <ul class="list">
      <li onclick="toggleText('texte1',1)" class="deroule"><img id="monImage1" src="fleche.png" class="deroule"><div class="titre">RENCONTER UN PSYCHIATRE ET/OU UN PSYCHOLOGUE</div></li>
      <p id="texte1" class="hidden">
        <?php
        $file = fopen("deroule1.txt","r");
        $contenu=fread($file,filesize("deroule1.txt"));
        echo $contenu;
        fclose($file);
        ?>
      </p>
      <li onclick="toggleText('texte2',2)" class="deroule"><img id="monImage2" src="fleche.png" class="deroule"><div class="titre">RENCONTRER DES PERSONNES QUI ONT VÉCU LA MÊME CHOSE QUE VOUS</div></li>
      <p id="texte2" class="hidden">
        <?php
        $file = fopen("deroule2.txt","r");
        $contenu=fread($file,filesize("deroule2.txt"));
        echo $contenu;
        fclose($file);
        ?></p>
      <li onclick="toggleText('texte3',3)" class="deroule"><img id="monImage3" src="fleche.png" class="deroule"><div class="titre">ME RÉINVESTIR DANS MON PARCOURS PROFESSIONNEL OU DE FORMATION</div></li>
      <p id="texte3" class="hidden">
        <?php
        $file = fopen("deroule3.txt","r");
        $contenu=fread($file,filesize("deroule3.txt"));
        echo $contenu;
        fclose($file);
        ?></p>
      <li onclick="toggleText('texte4',4)" class="deroule"><img id="monImage4" src=fleche.png class="deroule"><div class="titre">ME RESSOURCER</div></li>
      <p id="texte4" class="hidden">
        <?php
        $file = fopen("deroule4.txt","r");
        $contenu=fread($file,filesize("deroule4.txt"));
        echo $contenu;
        fclose($file);
        ?></p>
        <li onclick="toggleText('texte5',5)" class="deroule"><img id="monImage5" src=fleche.png class="deroule"><div class="titre">PARTICIPER A UNE MESURE DE JUSTICE RESTAURATIVE</div></li>
        <p id="texte5" class="hidden">
          <?php
          $file = fopen("deroule5.txt","r");
          $contenu=fread($file,filesize("deroule5.txt"));
          echo $contenu;
          fclose($file);
        ?></p>
      </ul>
      <script type="text/javascript" src="deroule.js"></script>
    </div>