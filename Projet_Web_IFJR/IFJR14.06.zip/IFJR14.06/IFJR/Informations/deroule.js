var angleRotation=[0,0,0,0,0,0];
function toggleText(elementId,i) {

  var element = document.getElementById(elementId);
  if (element.classList.contains("hidden")) {
    element.classList.remove("hidden");
  } else {
    element.classList.add("hidden");
  }
  var monImage = document.getElementById("monImage"+i);

    // Vérifier l'angle de rotation actuel
    if (angleRotation[i] === 0) {
      // Si l'angle est de 0, faire une rotation
      monImage.style.transform = "rotate(90deg)";
      angleRotation[i]= 90;
    } else {
      // Sinon, rétablir la rotation à 0 degré
      monImage.style.transform = "rotate(0deg)";
      angleRotation[i]= 0;
    }
}
