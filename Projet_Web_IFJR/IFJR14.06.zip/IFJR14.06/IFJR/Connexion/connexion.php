<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Connexion</title>
    <link rel="stylesheet" type="text/css" href="connexion.css" />
  </head>
  <body>
    <center>
      <form class="C" action="verifconnexion.php" method="post">
      <label>Identifiant :</label><input type="text" name="identifiant" value="">
      <label>Mot de Passe :</label><input type="password" name="password" value="">
            <div class="container">
        <div>
          <input class="log" id="Bouton" type="submit" name="" value="Connexion">
        </div>
      </div>
    </center>
  </body>
</html>
