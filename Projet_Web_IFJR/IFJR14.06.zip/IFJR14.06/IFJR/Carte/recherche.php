

<div>
  <h2 class="title">Trouver un correspondant dans votre département</h2>
</div>
<br>
<div class="txt">
  Depuis 2018, l’IFJR effectue, avec le soutien du Ministère de la justice, ses actions d’accompagnement sur les territoires du Sud-Est, du Nord-Est, du Sud-Ouest et de l’Île de la Réunion via quatre antennes.</p>
</div>

<div>
  <form class="search-bar" action="referent.php" method="post">
    <input type="text" name="recherche" placeholder="Recherchez Via votre N° de Département">
    <br>
    <input type="submit" value="Rechercher">
  </form>
</div>
