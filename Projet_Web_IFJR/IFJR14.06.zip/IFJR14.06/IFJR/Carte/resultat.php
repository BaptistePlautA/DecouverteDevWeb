<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Résultat</title>
    <link rel="stylesheet" href="resultat.css">
  </head>
  <body>
    <?php
    $compt=0;
    $row = 1;
    if (($handle = fopen("ville.csv", "r")) !== FALSE) {
        while (($data = fgetcsv($handle, 1000, ";")) !== FALSE) {
            $num = count($data);
            $row++;
            for ($c=0; $c < $num; $c++) {
                if ($data[0]==$_POST["recherche"]||$data[1]==$_POST["recherche"]) {
                  $region[$compt]=$data[0];
                  $numero[$compt]=$data[1];
                  $antenne[$compt]=$data[2];
                }
            }
        }
        fclose($handle);
    }

if ($antenne[$compt]=="SE") {
  $nom="Noémie Micoulet";
  $num="07 81 12 51 89";
  $mail="coordination.sud-est@justicerestaurative.org";
  $titre="titreSE";
}else {
  if ($antenne[$compt]=="SO") {
    $nom="Émilie Matignon et Eulalie Spychiger";
    $num="06 77 99 27 15 et 06 32 57 71 25";
    $mail="coordination.sud-ouest@justicerestaurative.org";
    $titre="titreSO";
  }else {
    if ($antenne[$compt]=="NE") {
      $nom="Héloïse Squelbut";
      $num="06 08 99 80 44";
      $mail="coordination.nord-est@justicerestaurative.org";
      $titre="titreNE";
    }else {
      if ($antenne[$compt]=="RE") {
        $nom="Océane Laburre et Émilie LE PORT";
        $num="0693 802 803 et 0693 855 311";
        $mail="coordination.reunion@justicerestaurative.org";
        $titre="titreRE";
      }else {
        echo "Aucun référent disponible dans votre département";
        $nom="";
        $num="";
        $mail="";
        $region[$compt]="";
      }
    }
  }
}
?>
<div>
    <span class=<?php echo $titre; ?> id="titrebarre"><?php echo $region[$compt]; ?></span>
    <span class=infobarre><?php echo $nom ;?></span>
    <span class=infobarre><?php echo $num ;?></span>
    <span class=infobarre><?php echo $mail ;?></span>
</div>


<script type="text/javascript" src="resultat.js"></script>
  </body>
</html>
