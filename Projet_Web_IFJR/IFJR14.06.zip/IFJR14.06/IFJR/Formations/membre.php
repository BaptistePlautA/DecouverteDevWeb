<!DOCTYPE html>
<html lang="fr">
  <head>
    <meta charset="UTF-8" />
    <meta name="description" content="IFJR">
    <meta name="author" content="PLAUT-AUBRY Baptiste">
    <link rel="stylesheet" href="../CSS/InfoIFJR.css">
    <link rel="stylesheet" href="../CSS/Fichettes.css">
    <link rel="stylesheet" href="../HeaderFooter/header.css">
    <link rel="stylesheet" href="../HeaderFooter/footer.css">
    <link rel="stylesheet" href="../CSS/Formations.css">
    <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet">
    <title>Informations</title>
  </head>

<header>
    <?php
      include("../HeaderFooter/header.php");
    ?>
</header>

<body>
    <div class="name">
      Formation : Membre – Devenir membre de la communauté...
    </div>
    <div class="Formation">
      <div class="info">

        <h1>Le contexte</h1>
        La justice restaurative a pour seul objectif d’offrir, à toutes les personnes concernées par le crime, un espace de dialogue sécurisé et respectueux de tous ceux qui y participent.<br> <br>

        Elle a pour finalité, la restauration de tous par :<br>
        <ul>
          <li>La resocialisation de la personne infracteure</li>
          <li>La réintégration de la personne victime après réparation de tous ses préjudices</li>
          <li>Le rétablissement de la paix sociale au sein de la communauté</li>
        </ul>
        <br>


        <!--<a href="https://www.justicerestaurative.org/">https://www.justicerestaurative.org/en-savoir-plus/</a>-->

        Cette formation propose une méthodologie pour mettre en place un projet de justice restaurative avec différents partenaires dont les associations d’aide aux victimes, les services pénitentiaires et les services de la protection judiciaire de la jeunesse, en milieu ouvert ou en milieu fermé. <br>La formation permet de travailler sur la première étape, qui est la construction du projet. Elle aborde également les bases théoriques du rôle et de la posture des animateurs et animatrices des mesures de justice restaurative et prépare donc au module 2 du parcours. <br> <br>

       <h1> À qui s’adresse cette formation ?</h1>

        <h2>Le public visé</h2>

        Cette formation s’adresse aux personnes souhaitant devenir animateur / animatrice de mesures de justice restaurative. Elle est réservée aux : <br>
         <ul>
           <li>Personnels de l’Administration pénitentiaire ou de la Protection judiciaire de la jeunesse ;</li>
           <li>Magistrats, greffiers ;</li>
           <li>Membres des associations d’aides aux victimes, notamment.</li>
         </ul>
         <br>


        En effet, la justice restaurative en France est actuellement portée par le ministère de la Justice et les associations, conventionnées ou agréées par ce dernier. <br> <br>

        Ce module 1 est un prérequis pour suivre le module 2 permettant d’accéder au Certificat d’aptitude à l’animation de mesures de justice restaurative. <br><br>

        Toutefois, ce module 1 s’adresse aussi aux personnes qui, sans avoir le projet de devenir animateur ensuite, souhaiteraient néanmoins s’impliquer dans un programme de justice restaurative.<br><br>

        <h2>Personnes en situation de handicap :</h2>

        Toutes nos formations sont ouvertes aux personnes en situation de handicap. La faisabilité des adaptations à envisager sera étudiée en fonction des besoins communiqués par l’apprenant.<br>

       <br> Contactez  <!--<a href="#">referent-handicap@justicerestaurative.org</a>-->

        <h2>Pré-requis</h2>

        Maitrise de la langue française <br>

        <h1>Les objectifs de la formation</h1>
        <ul>
          <li> Expliquer aux justiciables ce qu’est la justice restaurative (bienfaits et limites) pour informer des dispositifs et orienter</li>
          <li> Utiliser les protocoles et cadres d’intervention pour choisir les mesures et intervenants appropriés</li>
          <li> Préparer les participants à une mesure de justice restaurative</li>
        </ul>

        Les compétences visées sont :
    <ul>
    <li>S’approprier les principes de la justice restaurative</li>
    <li>Connaître le cadre d’intervention des programmes et mesures de justice restaurative</li>
    <li>Connaître le protocole de mise en oeuvre d’un programme de justice restaurative</li>
    <li>Savoir informer et orienter des personnes victimes ou autrices d’infractions pénales vers une mesures de justice restaurative</li>
    <li>Découvrir les bases théoriques et méthodologiques de la préparation au dialogue en justice restaurative</li>
    <li>Identifier le protocole de mise en oeuvre de la médiation restaurative</li>
    <li>Identifier le protocole de mise en oeuvre des conférences restauratives et autres mesures en groupes</li>
    <li>Découvrir le protocole de mise en oeuvre des CSR-CAR.</li>
    </ul>


        <h1>Le contenu de la formation</h1>

    <ul>
    <li>La justice restaurative : Principes et promesses</li>
    <li>Le cadre normatif de la justice restaurative en France</li>
    <li>Le cadre opérationnel de la justice restaurative en France</li>
    <li>L’information et l’orientation</li>
    <li>L’approche relationnelle</li>
    <li>La médiation restaurative</li>
    <li>La conférence restaurative / Les RDV-RCV / Le cercle restauratif</li>
    <li>Les CSR-CAR.</li>
    </ul>

        <h1>Les méthodes utilisées</h1>
    <ul>
    <li>Exposé, apports de connaissances</li>
    <li>Questions / Réponses</li>
    <li>Questions / Réponses</li>
    <li>Echange / Débat</li>
    </ul>

        <h1>Les ressources pédagogiques</h1>

    <ul>
    <li>Livret pédagogique</li>
    <li>PowerPoint</li>
    <li>Webinaire</li>
    <li>Vidéos</li>
    <li>Film</li>
    <li>Dossier post formation : circulaires, formulaires types, dépliants, guides, etc.</li>

    </ul>

        <h1>Les modalités d’évaluation</h1>
        <ul>
          <li>Auto-évaluations</li>
          <li>Quizz</li>
          <li>Evaluations formatives au travers des échanges et cas pratiques</li>
          <li>Test de connaissances</li>
          <li>Questionnaire de satisfaction</li>
        </ul>


        Une attestation de réalisation sera remise à l’apprenant à l’issue de la formation.

        <h1>Les modalités de suivi</h1>

        L’intervenant.e reste disponible pour les apprenants pendant 6 mois après la formation.

        <h1>Profils et expérience de nos intervenants</h1>

        Tous nos intervenants sont des spécialistes experts de la Justice Restaurative.<br>

        En plus d’être formateurs, leurs activités professionnelles couvrent :

    <ul>
    <li>L’animation de mesures de justice restaurative (médiations restauratives, rencontres détenus ou condamnés / victimes)</li>
    <li>La supervision technique de l’animation de mesures de justice restaurative</li>
    <li>La gestion de projets et l’accompagnement dans la mise en oeuvre de programmes de justice restaurative</li>
    <li>Les actions de sensibilisation et d’échanges de pratiques dans le domaine de la justice restaurative</li>
    <li>Des travaux de recherches autour de la justice restaurative, etc</li>

    </ul>
        Dernière mise à jour : mai 2023

      </div>

      <div class="sticky">
        <h1> Les prochaines sessions</h1>
       <span>Format : </span> en présentiel <br>
       Groupe de 12 à 20 personnes <br>
       Durée : 4 jours (30 heures)<br>

       BOUTON <br>

       <h1>Les tarifs</h1>

       L’IFJR met son expertise à disposition de la fédération France Victimes et de l’École Nationale d’Administration Pénitentiaire (ENAP).<br>

       L’IFJR met également en place des formations avec certaines Directions Interrégionales des Services Pénitentiaires DISP et Directions Territoriales de la Protection Judiciaire de la Jeunesse DTPPJ. L’inscription à ces formations est généralement réservée aux agents de ces DISP et DTPJJ. <br>

       Merci de vous rapprocher de ces structures qui vous informeront sur leurs tarifs et modalités d’accès.<br>

       <h1>Contactez </h1>
             FORM
      </div>
    </div>
</body>

<footer>
  <?php
    include("../HeaderFooter/footer.php");
  ?>
</footer>
  </html>
