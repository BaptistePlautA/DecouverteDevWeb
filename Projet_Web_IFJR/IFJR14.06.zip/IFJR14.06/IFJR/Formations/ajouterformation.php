<!DOCTYPE html>
<html>
<head>
<title>enregistrement</title>
<meta http-equiv="content-type" content="text/html; charset=utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
<span id="a"><?php echo $_POST["titre"].".php";?></span>
<?php
// Chemin vers le fichier CSV

// Valeur à ajouter au tableau CSV
$nouvelElement = [$_POST["titre"],$_POST["des"]];

// Ouvrir le fichier CSV en mode ajout (a+)
if (($fichier = fopen("formation.csv", 'a+')) !== false) {

    // Ajouter la nouvelle ligne au fichier CSV
    fputcsv($fichier, $nouvelElement, ';');


    // Fermer le fichier
    fclose($fichier);

    echo 'Élément ajouté avec succès au fichier CSV.';
} else {
    echo 'Erreur lors de l\'ouverture du fichier CSV.';
}
?>

<script>
  window.location.href = "NosformationAdmin.php";
</script>
</body>
</html>
