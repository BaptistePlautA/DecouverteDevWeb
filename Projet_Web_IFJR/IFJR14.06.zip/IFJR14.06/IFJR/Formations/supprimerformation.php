<!DOCTYPE html>
<html>
<head>
<title>enregistrement</title>
<meta http-equiv="content-type" content="text/html; charset=utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
<span id="a"><?php echo $_POST["titre"].".php";?></span>
<?php
// Chemin vers le fichier CSV
$cheminFichier = 'formation.csv';

// Nom de la première colonne de la ligne à supprimer
$nomColonneASupprimer = $_POST["titre"]; // Remplacez par le nom de colonne approprié

// Ouvrir le fichier CSV en mode lecture et écriture (r+)
if (($fichier = fopen($cheminFichier, 'r+')) !== false) {
    // Verrouiller le fichier pour éviter d'autres écritures simultanées
    flock($fichier, LOCK_EX);

    // Créer un tableau pour stocker les lignes du fichier CSV
    $nouveauContenu = array();

    // Lire chaque ligne du fichier CSV
    while (($ligne = fgets($fichier)) !== false) {
        // Diviser la ligne en un tableau en utilisant le délimiteur CSV (point-virgule dans ce cas)
        $elements = explode(';', $ligne);

        // Vérifier si le nom de la première colonne correspond à celui recherché
        if ($elements[0] !== $nomColonneASupprimer) {
            // Ajouter la ligne au nouveau contenu
            $nouveauContenu[] = $ligne;
        }
    }

    // Réécrire le contenu du fichier avec le nouveau contenu
    ftruncate($fichier, 0); // Tronquer le fichier à 0 octet
    rewind($fichier); // Remettre le pointeur au début du fichier

    // Écrire le nouveau contenu dans le fichier
    foreach ($nouveauContenu as $ligne) {
        fwrite($fichier, $ligne);
    }

    // Déverrouiller le fichier
    flock($fichier, LOCK_UN);

    // Fermer le fichier
    fclose($fichier);

    echo 'Ligne supprimée avec succès du fichier CSV.';
} else {
    echo 'Erreur lors de l\'ouverture du fichier CSV.';
}
?>



<script>
  window.location.href = "NosformationAdmin.php";
</script>
</body>
</html>
