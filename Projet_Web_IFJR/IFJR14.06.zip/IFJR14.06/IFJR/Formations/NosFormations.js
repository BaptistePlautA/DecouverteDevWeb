const boxes = document.querySelectorAll('[id^="box"]');

boxes.forEach((box) => {
  const h3 = box.querySelector('h3');
  const em = box.querySelector('em');

  box.addEventListener('mouseenter', () => {
    box.style.transition = 'background-color 0.5s cubic-bezier(.785,.135,.15,.86)';
    h3.style.transition = 'color 0.3s ease-in-out';
    em.style.transition = 'color 0.3s ease-in-out';
    box.style.backgroundColor = '#0aA79B';
    h3.style.color = 'white';
    em.style.color = 'white';
  });

  box.addEventListener('mouseleave', () => {
    box.style.transition = 'background-color 0.5s cubic-bezier(.785,.135,.15,.86)';
    h3.style.transition = 'color 0.3s ease-in-out';
    em.style.transition = 'color 0.3s ease-in-out';
    box.style.backgroundColor = '';
    h3.style.color = '';
    em.style.color = '';
  });
});

