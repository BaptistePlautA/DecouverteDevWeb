<!DOCTYPE html>
<html>
<head>
<title>enregistrement</title>
<meta http-equiv="content-type" content="text/html; charset=utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
<span id="a"><?php echo $_POST["nbr"];?></span>
<?php

function supprimerLigneCSV($cheminFichier, $numLigne) {
    // Lire le contenu du fichier CSV
    $contenu = file($cheminFichier);

    // Vérifier si le numéro de ligne est valide
    if ($numLigne >= 0 && $numLigne < count($contenu)) {
        // Supprimer la ligne spécifiée
        unset($contenu[$numLigne]);

        // Réorganiser les clés du tableau
        $contenu = array_values($contenu);

        // Réécrire le fichier CSV
        file_put_contents($cheminFichier, implode("", $contenu));

        echo "La ligne $numLigne a été supprimée avec succès.";
    } else {
        echo "Le numéro de ligne est invalide.";
    }
}

// Exemple d'utilisation
$cheminFichier = "ville.csv";
$numLigne = $_POST["nbr"]-1; // Numéro de ligne à supprimer (commence à zéro)

supprimerLigneCSV($cheminFichier, $numLigne);

?>




<script>
  window.location.href = "VillesFormationsAdmin.php";
</script>
</body>
</html>
