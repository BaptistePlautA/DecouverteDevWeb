<div class="header">
  <img src="../IFJR.png" width="7%" alt="">
  <ul class="gauche">
    <li>
      <a href="https://www.justicerestaurative.org/">IFJR</a>
    </li>
    <li>
      <a href="../Frontpage/Frontpage.php">FORMATIONS</a>
    </li>
  </ul>
    <ul class="droite">
      <li>
        <a href="../Connexion/connexion.php">CONNEXION</a>
      </li>
      <li>
        <a href="https://www.justicerestaurative.org/nous-contacter/">NOUS CONTACTER</a>
    </ul>
</div>
<div class="recolor_top">
  <br>
  </div>